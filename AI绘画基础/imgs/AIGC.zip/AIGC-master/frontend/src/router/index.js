import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '@/views/HomeView.vue';
import RegisterView from '@/views/RegisterView.vue';
import LoginView from '@/views/LoginView.vue';
import DashboardView from '@/views/DashboardView.vue';
import ProfileView from '@/views/ProfileView.vue';
import NoteView from '@/views/NoteView.vue';
import EditNoteView from '@/views/EditNoteView.vue';
import store from '@/store'; // NEW
import FileUploadView from '@/views/FileUploadView.vue';
import FileDownloadView from '@/views/FileDownloadView.vue';

import DrawingsIndexView from '@/views/Drawings/IndexView.vue';
import DrawingsMapMakingView from '@/views/Drawings/MapMakingView.vue';


const routes = [
  {
    path: '/',
    name: "Home",
    component: HomeView,
  },
  {
    path: '/register',
    name: 'Register',
    component: RegisterView,
  },
  {
    path: '/login',
    name: 'Login',
    component: LoginView,
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: DashboardView,
    meta: { requiresAuth: true },
  },
  {
    path: '/fileupload',
    name: 'FileUpload',
    component: FileUploadView,
    meta: { requiresAuth: true },
  },
  {
    path: '/filedownload',
    name: 'FileDownload',
    component: FileDownloadView,
    meta: { requiresAuth: true },
  },
  {
    path: '/profile',
    name: 'Profile',
    component: ProfileView,
    meta: { requiresAuth: true },
  },
  {
    path: '/note/:id',
    name: 'Note',
    component: NoteView,
    meta: { requiresAuth: true },
    props: true,
  },
  {
    path: '/editnote/:id',
    name: 'EditNote',
    component: EditNoteView,
    meta: { requiresAuth: true },
    props: true,
  },

  {
    path: '/drawings',
    name: "DrawingsIndex",
    component: DrawingsIndexView,
  },
  {
    path: '/drawings-map-making',
    name: "DrawingsMapMaking",
    component: DrawingsMapMakingView,
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

router.beforeEach((to, _, next) => {
  console.log('to', to)

  if (to.matched.some(record => record.meta.requiresAuth)) {
    
    if (store.getters.isAuthenticated) {
      next();
      return;
    }
    next('/login');
  } else {
    next();
  }
});

export default router;
