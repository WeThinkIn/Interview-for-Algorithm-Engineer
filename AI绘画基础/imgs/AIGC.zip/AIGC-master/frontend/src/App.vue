<template>
  <div class="w-full min-h-screen">
    <!-- <NavBar /> -->
    <!-- <div class="main container">
      <router-view/>
    </div> -->
    <router-view/>
  </div>
</template>

<script>
// @ is an alias to /src
// import NavBar from '@/components/NavBar.vue'
// export default {
//   components: {
//     NavBar
//   }
// }
</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
.main {
  padding-top: 5em;
} */
</style>
