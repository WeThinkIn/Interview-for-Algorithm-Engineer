<template>
    <div :class="`absolute top-0 left-0 w-full h-full bg-black/80 flex flex-row justify-center items-center ${show ? '' : 'hidden'}`">
        <slot></slot>
    </div>
</template>

<script setup name="Modal">
import { ref, watch } from 'vue'

const props = defineProps({
    show: Boolean
})

</script>