<template>
    <div :class="`flex flex-col w-full min-h-screen bg-[url('./assets/images/bg.png')] bg-center bg-no-repeat bg-[length:100%_100%]`">
        <nav class="h-[10vh] flex flex-row justify-between items-center bg-[url('./assets/images/nav_bg.png')] bg-center bg-no-repeat bg-[length:100%_100%] pb-[1.5vh] px-[3vw]">
            <div class="cursor-pointer">
                <img @click="() => router.go(-1) " class="w-[2vw] h-[2.6vh]" src="@/assets/images/left.png" />
            </div>
            <div class="text-white text-[3.2vh] font-bold">{{title}}</div>
            <div class="w-[2vw] h-full"></div>
        </nav>
        <div class="flex-1 flex flex-col">
            <slot></slot>
        </div>
    </div>
</template>

<script setup name="Layout">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router';

const router = useRouter()

const props = defineProps({
    title: {
        type: String,
        default: ''
    }
})

</script>