<template>
  <div class="w-full min-h-screen bg-[url('./assets/images/home/bg.png')] bg-center bg-no-repeat bg-[length:100%_100%] pt-[30vh]">
    <div v-for="(item, index) in items" :key="index" class="px-[4vw] w-full aspect-[16/3] mb-[3vh]" @click="() => router.push({name: item.url })">
      <div class="relative w-full text-white bg-[url('./assets/images/home/items_bg.png')] bg-center bg-no-repeat bg-[length:100%_100%] h-full flex flex-col justify-center px-10 cursor-pointer">
        <div class="text-[2.6vh]">{{ item.title }}</div>
        <div class="text-[1vh]">{{ item.subtitle }}</div>
        <img class="absolute -top-[8%] right-[6%] w-[36%] h-[90%]" :src="item.images" />
      </div>
    </div>
  </div>
</template>
<script setup name="HomeView">
import { useStore } from 'vuex';
import { ref, reactive, computed } from 'vue'
import { useRouter } from 'vue-router';

const store = useStore();
const router = useRouter();

const isLoggedIn = computed(() => store.getters.isAuthenticated);

const items = ref([
  { title: 'AI制图', subtitle: 'AI Mapping', images: require('@/assets/images/home/items_1.png'), url:"DrawingsIndex" },
  { title: 'AI视频', subtitle: 'AI Video', images: require('@/assets/images/home/items_2.png'), url:"FileUpload" },
  { title: '语音对话', subtitle: 'Voice Conversation', images: require('@/assets/images/home/items_3.png'), url:"FileDownload" },
  { title: '音乐谱曲', subtitle: 'Music Composition', images: require('@/assets/images/home/items_4.png'), url:"Profile" },
])
</script>
