<template>
    <div>
      <input type="text" v-model="filePath" placeholder="文件路径" />
      <button @click="downloadFile">下载文件</button>
    </div>
  </template>
  
  <script>
import axios from 'axios';
import { mapGetters } from 'vuex';


  export default {
  computed: {
    ...mapGetters(['stateUser']), // 获取用户的 token
  },
  methods: {
  async downloadFile() {
    const storageId = "6603de702f78855a73986c1e"
    const filePath = "95987d.docx"
    try {
      const response = await axios.get(`/files/?storage_id=${storageId}&file_path=${filePath}`, {
        headers: {
          'Authorization': `Bearer ${this.stateUser.access_token}`, // 从 Vuex store 获取 token
        },
        responseType: 'blob', // 重要：设置响应类型为blob，以便处理二进制文件内容
      });

      // 创建一个URL对象并生成临时的下载链接
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;

      // 假设你的filePath形式如 "folder/filename.ext"，提取文件名
      const filename = filePath.split('/').pop();
      link.setAttribute('download', filename); // 设置下载文件名

      document.body.appendChild(link);
      link.click(); // 触发下载

      // 清理临时URL和链接元素
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed', error);
      alert('Download failed');
    }
  }
}
,
  };
  </script>
  