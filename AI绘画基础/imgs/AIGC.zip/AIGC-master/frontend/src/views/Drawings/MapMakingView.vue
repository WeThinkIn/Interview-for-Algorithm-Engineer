<template>
    <Layout title="AI制图">
        <div class="flex-1 flex flex-col">
            <div>
                <!-- <img class="w-[85vw] aspect-[20/21] m-auto rounded-xl" src="@/assets/images/drawings/cameras_video_to.png" /> -->
                <img class="w-[85vw] aspect-[20/21] m-auto rounded-xl" :src="imagesAI ?? drawingsImage" />
            </div>
            <!-- <div class="w-[85vw] mx-auto my-[2vh]">
                <div @click="addTag" class="bg-[url('~@/assets/images/drawings/tag.png')] bg-center bg-no-repeat bg-[length:100%_100%] w-[20vw] h-[3.6vh] pl-[8vw] text-[1.3vh] leading-[3.6vh] text-white cursor-pointer">添加标签</div>
            </div> -->
            <div class="w-[85vw] mx-auto text-[1.6vh] leading-[2vh] text-white mt-[1vh]">选择您想要的标签</div>
            <div class="w-[85vw] mx-auto text-white flex flex-col gap-[2vh] mt-[1vh]">
                <div v-for="(item, index) in tags" :key="index" class="flex flex-col gap-y-[.3vh]">
                    <div class="text-[1.2vh]">{{ item.title }}</div>
                    <div class="grid grid-cols-5 gap-x-[3vw] gap-y-[1vh]">
                        <div v-for="(item_, index_) in item.data" :key="index_" @click="() => {
                    if (item?.multiple) {
                        if (!item.active.includes(index_)) {
                            item.active.push(index_);
                        } else {
                            item.active = item.active.filter(item__ => item__ !== index_);
                        }
                        return
                    }
                    item.active = !item.active.includes(index_) ? [index_] : [];
                }" :class="`text-center border border-white rounded-[3vh] text-[1vh] py-[.2vh] cursor-pointer ${item.active.includes(index_) ? 'bg-gradient-to-r from-[#e78787]' : ''}`">
                            {{ item_.name }}
                        </div>
                    </div>
                </div>
            </div>

            <!-- <div class="w-[85vw] mx-auto text-[1.6vh] leading-[2vh] text-white">
                选择您想要的风格
            </div>
            <div class="overflow-x-auto ml-[4.6vw] mr-[2.6vw] mt-[1vh]">
                <div class="flex flex-row">
                    <div v-for="(item, index) in styles" :key="index" class="flex-none cursor-pointer flex flex-col items-center">
                        <div class="relative">
                            <img class="w-[10.6vh] aspect-[1/1] " :src="item.src" />
                            <div :class="`w-full h-full absolute top-0 left-0 ${index === 0 ? '' : 'bg-black/50'}`"></div>
                        </div>
                        <span class="text-[1.3vh] leading-[2vh] text-white">{{ item.name }}</span>
                    </div>
                </div>
            </div> -->
        </div>
        <div class="flex flex-row justify-center items-center pb-[2.3vh]">
            <div @click="createIA"
                class="bg-[url('~@/assets/images/drawings/buttom_bg.png')] bg-center bg-no-repeat bg-[length:100%_100%] text-white text-[2.6vh] w-[85vw] h-[8vh] text-center leading-[8vh] cursor-pointer">
                <span class="pl-[10vw]">开始制作</span>
            </div>
        </div>
    </Layout>

    <!-- <Modal :show="showTagModal">
        <div class="w-[80vw] h-[60vh] flex flex-col gap-[2vh]">
            <div class="rounded-[1.6vh] bg-[linear-gradient(to_right,#7049f8,#051c62)] px-[6vw] py-[3vh]">
                <div class="flex flex-row justify-center items-center gap-[2vw]">
                    <img class="w-[4vw] h-[2.8vh]" src="@/assets/images/tag.png" />
                    <span class="text-white text-[2vh]">添加标签</span>
                </div>
                <div class="pt-[3vh]">
                    <img src="@/assets/images/line.png" alt="">
                </div>
                <div class="text-white flex flex-col gap-[2vh] mt-[2vh]">
                    <div v-for="(item, index) in tags" :key="index" class="flex flex-col gap-[.5vh]">
                        <div class="text-center text-[1.8vh]">{{ item.title }}</div>
                        <div class="grid grid-cols-3 gap-[2vw]">
                            <div v-for="(item_, index_) in item.data" :key="index_"
                                :class="`text-center border border-white rounded-[3vh] h-[5vh] leading-[5vh] text-[1.6vh] cursor-pointer ${index_ === item.active ? 'bg-gradient-to-r from-[#e78787]' : ''}`">
                                {{ item_.name }}
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="mt-[6vh] bg-[#e78787] text-[2vh] h-[5vh] rounded-[3vh] text-center leading-[5vh] text-white cursor-pointer">
                    确定
                </div>
            </div>
            <div class="flex flex-row justify-center items-center cursor-pointer" @click="showTagModal = false">
                <img class="w-[10vw] aspect-[1/1]" src="@/assets/images/delete.png" />
            </div>
        </div>
    </Modal> -->

    <Modal :show="showCreateAIModal">
        <div class="h-[60vh] flex flex-col gap-[2vh]">
            <div
                class="rounded-[1.6vh] bg-[url('~@/assets/images/drawings/create_ai_bg.png')] bg-center bg-no-repeat bg-[length:100%_100%] px-[6vw] py-[3vh] pt-[5vh]">
                <div
                    class="bg-[url('@/assets/images/drawings/create_ai_img.png')] bg-center bg-no-repeat bg-[length:100%_100%] w-[45vw] h-[3vh] text-center leading-[3vh] text-[1.3vh] text-white mx-auto">
                    MAKING ...
                </div>
                <div class="text-white text-[3.2vh] font-bold mt-[1vh] w-[45vw] mx-auto">图片正在制作中 ...</div>
                <img class="w-[20vw] aspect-[15vh] mx-auto mt-[1vh]"
                    src="@/assets/images/drawings/create_ai_img1.png" />
                <div class="text-white text-[2.3vh] -mt-[2vh]">预计时间还有30秒，请耐心等候 ...</div>
            </div>
            <div class="flex flex-row justify-center items-center cursor-pointer" @click="showCreateAIModal = false">
                <img class="w-[10vw] aspect-[1/1]" src="@/assets/images/delete.png" />
            </div>
        </div>
    </Modal>
</template>

<script setup name="DrawingsMapMaking">
import Layout from '@/components/Layout.vue'
import Modal from '@/components/Modal.vue'


import axios from 'axios';
import { ref, reactive, computed } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useStore } from 'vuex'

const store = useStore()
const stateUser = computed(() => store.getters['stateUser']) // 获取用户的token

const router = useRouter()
const route = useRoute()

const imagesAI = ref(null)
const drawingsImage = localStorage.getItem('drawingsImage')

const styles = ref([
    { name: '风格1', src: require('@/assets/images/drawings/styles.png'), name: "动漫" },
    { name: '风格2', src: require('@/assets/images/drawings/styles.png'), name: "二次元" },
    { name: '风格3', src: require('@/assets/images/drawings/styles.png'), name: "写实" },
    { name: '风格4', src: require('@/assets/images/drawings/styles.png'), name: "科幻" },
    { name: '风格5', src: require('@/assets/images/drawings/styles.png'), name: "宫崎骏风" },
])

const showTagModal = ref(false)
const addTag = () => {
    showTagModal.value = true
}
const tags = ref([
    {
        title: '角色',
        active: [0],
        data: [
            { name: '超人' },
            { name: '蜘蛛侠' },
            { name: '灭霸' },
            { name: '钢铁侠' },
            { name: '西方精灵' },
            { name: '花木兰' },
            { name: '艾莎公主' },
            { name: '神奇女侠' },
            { name: '公主' },
            { name: '女王' },
        ]
    },
    {
        title: '风景',
        active: [0],
        data: [
            { name: '天安门广场' },
            { name: '长城' },
            { name: '夏威夷海滩' },
            { name: '帝国大厦' },
            { name: '埃菲尔铁塔' },
        ]
    },
    {
        title: '元素',
        active: [0],
        multiple: true,
        data: [
            { name: '中国龙' },
            { name: '凤凰' },
            { name: '盔甲' },
            { name: '中国风' },
            { name: '汉服' },
            { name: '旗袍' },
            { name: '首饰' },
            { name: '黄金' },
            { name: '钻石' },
            { name: '王冠' },
        ]
    },
])

const showCreateAIModal = ref(false)
const createIA = async () => {
    showCreateAIModal.value = true

    if (!drawingsImage) return;

    // 获取标签
    const activeTags = []
    for (let i = 0; i < tags.value.length; i++) {
        const tag = tags.value[i]
        if (tag.active.length) {
            for (let j = 0; j < tag.active.length; j++) {
                activeTags.push(tag.data[tag.active[j]].name)
            }
        }
    }

    // const access_token = await stateUser.value.access_token
    const requestBody = {
        tags: [1, 2],
        file_base64: drawingsImage
    }
    const response = await axios.post('/files/base64_uploads/', requestBody, {
        // headers: {
        //     'Authorization': `Bearer ${access_token}`,
        // },
    });
    imagesAI.value = axios.defaults.baseURL + response.data

    setTimeout(() => {
        showCreateAIModal.value = false
    }, 1000);
}


</script>