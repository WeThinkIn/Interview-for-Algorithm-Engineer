<template>
    <Layout title="图片上传">
        <!-- <img class="w-[85vw] aspect-[3/4] m-auto rounded-xl" src="@/assets/images/drawings/cameras_video.png" /> -->
        <video ref="videoRef" class="w-[85vw] aspect-[3/4] m-auto rounded-xl bg-black" autoplay></video>

        <canvas ref="canvasRef" class="hidden"></canvas>

        <div class="flex flex-row justify-between items-center h-[16vh] px-[15vw] mb-[6vh]">
            <div class="w-[9vh]">
            </div>
            <div>
                <img class="w-[12vh] aspect-[1/1] cursor-pointer" @click="takeSnapshot"
                    src="@/assets/images/drawings/cameras.png" />
            </div>
            <div>
                <img class="w-[8vh] aspect-[1/1] mt-[1vh]" src="@/assets/images/drawings/image_upload.png" />
            </div>
        </div>
    </Layout>
</template>

<script setup name="DrawingsIndex">
import Layout from '@/components/Layout.vue'

import { ref, onMounted, onBeforeUnmount } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

const videoRef = ref(null);
const canvasRef = ref(null);
const photoRef = ref(null);
let mediaStream = null;
const startCamera = async () => {
    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        console.log(mediaStream)

        videoRef.value.srcObject = mediaStream;
    } catch (error) {
        console.error('调用摄像头失败:', error);
    }
};

const takeSnapshot = () => {
    if (videoRef.value && canvasRef.value) {
        const ctx = canvasRef.value.getContext('2d');
        canvasRef.value.width = videoRef.value.videoWidth;
        canvasRef.value.height = videoRef.value.videoHeight;
        ctx.drawImage(videoRef.value, 0, 0, canvasRef.value.width, canvasRef.value.height);

        // 将canvas转换为dataURL，然后显示在img标签中
        const dataURL = canvasRef.value.toDataURL('image/jpeg');
        console.log(dataURL)
        // photoRef.value.src = dataURL;
        // photoRef.value.style.display = 'block';
        localStorage.setItem('drawingsImage', dataURL)
        router.push({ name: 'DrawingsMapMaking' })
    }
    // router.push({ name: 'DrawingsMapMaking' })
}

const stopCamera = () => {
    if (mediaStream) {
        mediaStream.getTracks().forEach(track => track.stop());
        videoRef.value.srcObject = null;
    }
};

onMounted(() => {
    startCamera();
});

onBeforeUnmount(() => {
    stopCamera();
});

</script>