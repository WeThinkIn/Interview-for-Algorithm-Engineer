<template>
  <div>
    <input type="file" @change="selectFile" />
    <button @click="uploadFile">Upload</button>
  </div>
</template>


<script>
import axios from 'axios';
import { mapGetters } from 'vuex';

export default {
  computed: {
    ...mapGetters(['stateUser']), // 获取用户的 token
  },
  methods: {
    selectFile(event) {
      this.selectedFile = event.target.files[0];
    },
    async uploadFile() {
      if (!this.selectedFile) {
        alert('Please select a file first!');
        return;
      }
      
      // 准备请求体数据
      const requestBody = {
        name: new Date().getTime(), // 这里是静态值，根据实际情况替换
        platform: "minio",
        access_key: this.stateUser.minio_access_key,
        secret_key: this.stateUser.minio_secret_key,
        bucket_name: this.stateUser.minio_bucket_name,
      };
      try {
        // 使用 await 等待请求完成
        const response = await axios.post('/storages/', requestBody, {
          headers: {
            'Authorization': `Bearer ${this.stateUser.access_token}`, 
          },
        });
        console.log('Storage created successfully', response.data);
        const storageId = response.data.id;
        const formData = new FormData();
        formData.append('file', this.selectedFile); // 'file' 对应后端期待的文件字段
        formData.append('storage_id', storageId); // 添加 'storage_id'

        try {
          const response = await axios.post('/files/', formData, {
            headers: {
              'Authorization': `Bearer ${this.stateUser.access_token}`, // 从 Vuex store 获取 token
            },
          });
          console.log('File uploaded successfully', response);
          alert('File uploaded successfully');
        } catch (error) {
          console.error('Upload failed', error);
          alert('Upload failed');
        }
      } catch (error) {
        console.error('Failed to create storage', error);
        // 这里处理错误
      }
    },
  },
};
</script>
