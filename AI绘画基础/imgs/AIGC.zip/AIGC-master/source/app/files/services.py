from fastapi import UploadFile
from loguru import logger
from source.app.files.client import MinioClient
from source.app.storages.services import get_storage
from source.core.database import PyObjectId
from source.core.settings import settings

from typing import Tuple
from io import BytesIO
import os
from pathlib import Path
from base64 import b64decode
from PIL import Image
from source.core.database import PyObjectId, db
from source.app.files.utils import text2image

async def upload_file(
    user_id: PyObjectId, storage_id: PyObjectId, file: UploadFile
) -> dict | None:
    if storage := await get_storage(user_id=user_id, storage_id=storage_id):
        client = MinioClient(
            endpoint=storage.get("endpoint"),
            access_key=storage.get("access_key"),
            secret_key=storage.get("secret_key"),
            bucket_name=storage.get("bucket_name"),
        )
        client.upload_file(file=file)
        return {"filename": file.filename, "storage_id": storage_id}


async def download_file(
    user_id: PyObjectId, storage_id: PyObjectId, file_path: str
) -> str | None:
    if storage := await get_storage(user_id=user_id, storage_id=storage_id):
        client = MinioClient(
            endpoint=storage.get("endpoint"),
            access_key=storage.get("access_key"),
            secret_key=storage.get("secret_key"),
            bucket_name=storage.get("bucket_name"),
        )
        destination_folder = f"{settings.TEMP_FOLDER}/{user_id}"
        filename = file_path.split("/")[-1]
        logger.warning(filename)
        client.download_file(
            source=file_path, destination=f"{destination_folder}/{filename}"
        )
        return f"{destination_folder}/{filename}"


async def base64_upload_files(tags: str, file_data: str) -> str:
    try:
        # 解码Base64字符串
        no_prefix = file_data.split(",")[1]  # 使用逗号分隔并取第二个部分
        decoded_data = b64decode(no_prefix)

        # 从Base64字符串中提取文件类型
        # 注意：假设数据包含"data:image/<type>;base64,"前缀
        prefix, mime_type = file_data.split('data:image/', 1)
        image_type = mime_type.split(';')[0].split('/')[-1]

        file_name = f"user_{os.urandom(8).hex()}.{image_type}"  # 包含图片类型

        file_path = Path("source/public/uploads") / file_name  # 假设"uploads"是你的存储目录

        # 确保"uploads"目录存在
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # 使用PIL库验证图像数据
        try:
            image = Image.open(BytesIO(decoded_data))
            image.verify()
        except (IOError, SyntaxError) as e:
            raise ValueError("Invalid image data: {}".format(str(e)))

        # 保存图像到本地
        with Image.open(BytesIO(decoded_data)) as im:
            im.save(file_path)

        # 生成AI图像
        # file_path = text2image(tags, str(file_path.absolute()))
        # return file_path

        file_url = f"static/uploads/{file_path.name}"  # 示例URL，根据你的路由结构进行调整
        return file_url

        # file_url = f"/static/uploads/{file_path.name}"  # 示例URL，根据你的路由结构进行调整
        # db['files'].insert_one({
        #     "user_id": user_id,
        #     "file_name": file_name,
        #     "file_path": str(file_path.absolute()),
        #     "file_url": file_url,
        #     "created_at": datetime.utcnow()
        # })
        # return str(file_path.absolute()), file_url
        # return file_url
        
    except Exception as e:
        print(f"Error uploading file: {str(e)}")
        return None, None