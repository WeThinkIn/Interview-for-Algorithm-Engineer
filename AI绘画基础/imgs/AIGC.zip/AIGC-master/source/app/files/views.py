from fastapi import APIRouter, Depends, status, Body
from fastapi.background import BackgroundTasks
from fastapi.responses import FileResponse
from loguru import logger
from source.app.auth.auth import auth
from source.app.files.schemas import FileDownload, FileUpload, FileUploadResponse
from source.app.files.services import download_file, upload_file, base64_upload_files
from source.app.files.utils import remove_file
from source.core.schemas import ExceptionModel
from base64 import b64decode

file_router = APIRouter(prefix="/files", tags=["files"])


@file_router.post(
    "/",
    response_model=FileUploadResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        status.HTTP_401_UNAUTHORIZED: {"model": ExceptionModel},
        status.HTTP_404_NOT_FOUND: {"model": ExceptionModel},
    },
    tags=["files"],
)
async def file_upload(file: FileUpload = Depends(), user: dict = Depends(auth)):
    if uploaded := await upload_file(
        user_id=user.get("_id"), storage_id=file.storage_id, file=file.file
    ):
        return uploaded


@file_router.get(
    "/",
    response_class=FileResponse,
    responses={
        status.HTTP_401_UNAUTHORIZED: {"model": ExceptionModel},
        status.HTTP_404_NOT_FOUND: {"model": ExceptionModel},
    },
    tags=["files"],
)
async def file_download(
    background_tasks: BackgroundTasks,
    file: FileDownload = Depends(),
    user: dict = Depends(auth),
):
    logger.warning(file)
    background_tasks.add_task(
        remove_file, file.file_path.split("/")[-1], user.get("_id")
    )
    return await download_file(
        user_id=user.get("_id"), storage_id=file.storage_id, file_path=file.file_path
    )


@file_router.post(
    "/base64_uploads",
    status_code=status.HTTP_201_CREATED,
    responses={
        status.HTTP_401_UNAUTHORIZED: {"model": ExceptionModel},
        status.HTTP_404_NOT_FOUND: {"model": ExceptionModel},
    }
)
async def file_base64_uploads(tags: list=[], file_base64: str = Body(..., embed=True)):
    if uploaded := await base64_upload_files(tags=tags, file_data=file_base64):
        return uploaded
