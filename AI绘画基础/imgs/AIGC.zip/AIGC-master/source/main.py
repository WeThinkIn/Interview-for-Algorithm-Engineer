from asyncio import create_task
from contextlib import asynccontextmanager
from shutil import rmtree
from loguru import logger
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from source.app.storages.utils import create_minio_storage
from source.app.users.utils import create_admin_user
from source.core.settings import settings
from source.core.database import create_index
from source.core.health import minio_health, mongodb_health
from source.core.routers import api_router
from source.core.schemas import HealthModel

from fastapi.staticfiles import StaticFiles

@asynccontextmanager
async def lifespan(app: FastAPI):
    await create_index()
    await create_admin_user()
    await create_minio_storage()
    yield
    rmtree(settings.TEMP_FOLDER, ignore_errors=True)


app = FastAPI(title=settings.APP_TITLE, lifespan=lifespan)
logger.add("logs/ai_client.log", rotation="500 MB")
app.include_router(api_router)

origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#test
@app.get("/", response_model=HealthModel, tags=["health"])
async def health_check():
    mongodb_task = create_task(mongodb_health())
    minio_task = create_task(minio_health())
    mongodb = await mongodb_task
    minio = await minio_task
    return {"api": True, "mongodb": mongodb, "minio": minio}

# 指定静态文件目录，例如 "static" 文件夹位于项目根目录下
app.mount("/static", StaticFiles(directory="source/public"), name="static")